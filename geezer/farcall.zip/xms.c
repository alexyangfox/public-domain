/*----------------------------------------------------------------------------
Code to demonstrate farcall() function by accessing XMS driver
Chris Giese <geezer@execpc.com>	http://my.execpc.com/~geezer
Release date: Aug 18, 2005
This code is public domain (no copyright).
You can do whatever you want with it.
----------------------------------------------------------------------------*/
#include <stdio.h> /* printf() */
#include <dos.h> /* MK_FP(), struct REGPACK, intr() */

/* IMPORTS
from FARCALL.ASM */
void farcall(void far (*adr)(void), struct REGPACK *regs);
/*****************************************************************************
*****************************************************************************/
int main(void)
{
	void far (*xms_entry)(void);
	unsigned size, xms_handle;
	struct REGPACK regs;

/* detect XMS */
	regs.r_ax = 0x4300;
	intr(0x2F, &regs);
	if((regs.r_ax & 0xFF) != 0x80)
	{
		printf("Error: no XMS driver present\n");
		return 1;
	}
/* get XMS driver entry point */
	regs.r_ax = 0x4310;
	intr(0x2F, &regs);
	xms_entry = MK_FP(regs.r_es, regs.r_bx);
printf("XMS driver entry point: %Fp\n", xms_entry);
/* call XMS function 08h: "Query free extended memory"
returns size of largest block in AX (Kbytes) */
	regs.r_ax = 0x0800;
	regs.r_bx = 0;
	farcall(xms_entry, &regs);
printf("XMS memory: %uK total, %uK largest block\n", regs.r_dx, regs.r_ax);
	size = regs.r_ax;
/* call XMS function 09h: "Allocate extended memory block" of size DX (Kbytes)
returns status in AX (must be 1) and handle in DX */
	regs.r_ax = 0x0900;
	regs.r_dx = size;
	farcall(xms_entry, &regs);
	if(regs.r_ax != 1)
	{
		printf("Error: can't allocate XMS memory\n");
		return 1;
	}
	xms_handle = regs.r_dx;
/* call XMS function 0Ch: "Lock extended memory block" with handle DX
returns status in AX (must be 1) and linear address of block in DX:BX

This operation will fail in a Windows 9x DOS box and cause a dialog
to pop up, suggesting "MS-DOS mode" */
	regs.r_ax = 0x0C00;
	regs.r_dx = xms_handle;
	farcall(xms_entry, &regs);
	if(regs.r_ax != 1)
	{
		printf("Error: can't lock XMS memory\n");
/* call XMS function 0Ah: "Free extended memory block" with handle DX */
		regs.r_ax = 0x0A00;
		regs.r_dx = xms_handle;
		xms_entry();
/* this value of xms_handle indicates that XMS is not in use */
		xms_handle = -1u;
		return 1;
	}
printf("Locked XMS block at linear address 0x%lX\n",
 regs.r_dx * 65536L + regs.r_bx);
/* call XMS function 0Dh: "Unlock extended memory block" with handle DX */
	regs.r_ax = 0x0D00;
	regs.r_dx = xms_handle;
	farcall(xms_entry, &regs);
/* call XMS function 0Ah: "Free extended memory block" with handle DX */
	regs.r_ax = 0x0A00;
	regs.r_dx = xms_handle;
	farcall(xms_entry, &regs);
	return 0;
}
