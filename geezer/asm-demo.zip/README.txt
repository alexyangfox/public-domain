Assembly-language 'hello' programs for various OSes using
various assemblers and linkers
Chris Giese	<geezer@execpc.com>	http://my.execpc.com/~geezer
This code is public domain (no copyright).
You can do whatever you want with it.

Source file     Target OS       Assembler       Linker
-----------     ---------       --------------  -------------------------
dna.asm         DOS             NASM            ALINK
dnc.asm         DOS             NASM            (none -- .COM file)
dnb.asm         DOS             NASM            Borland TLINK

wbb.asm         Windows         Borland TASM    Borland ILINK32 and IMPORT32.LIB
wng.asm         Windows         NASM            GNU ld (and LIBKERNEL32.A; from MinGW)
wnb.asm         Windows         NASM            Borland ILINK32 and IMPORT32.LIB
wgg.s           Windows         GNU as          GNU ld (and LIBKERNEL32.A; from MinGW)

lng.asm         Linux           NASM            GNU ld
lgg.asm         Linux           GNU as          GNU ld
lww.asm         Linux           Watcom WASM     Watcom WLINK

