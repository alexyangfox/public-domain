/* hmmm...program crashes when FRACTION_BITS is >= 22
program freezes (infinite loop) when FRACTION_BITS is <= 7 */
#define	FRACTION_BITS	16
