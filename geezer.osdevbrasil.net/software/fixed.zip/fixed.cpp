/*----------------------------------------------------------------------------
FIXED-POINT CLASS
----------------------------------------------------------------------------*/
#include "fixed.h"	/* FRACTION_BITS */

#define	FIXED_MULT	(1L << (FRACTION_BITS))

#if defined(__WATCOMC__)
/* use stack-based calling convention (instead of registers),
and use leading underscores on names (instead of trailing underscores) */
#define	CDECL	cdecl
#else
#define	CDECL	/* nothing */
#endif

extern "C" void CDECL mul64(long *, long, long); /* 32*32 -> 32 multiply */
extern "C" void CDECL div64(long *, long, long); /* 32/32 -> 32 divide */

class fixed
{
private:
protected:
	/* long data; */
public:
	long data;
/* constructors */
	fixed::fixed()
	{
	}
	fixed::fixed(int i_data)
	{
		this->data=(long)i_data << FRACTION_BITS;
	}
	fixed::fixed(long i_data)
	{
		this->data = i_data << FRACTION_BITS;
	}
	fixed::fixed(double i_data)
	{
		this->data = (long)(i_data * FIXED_MULT);
	}
/* boolean operators */
	int fixed::operator <(fixed right)
	{
		return (this->data < right.data) ? 1 : 0;
	}
	int fixed::operator >(fixed right)
	{
		return (this->data > right.data) ? 1 : 0;
	}
	int fixed::operator !=(fixed right)
	{
		return (this->data != right.data) ? 1 : 0;
	}
	int fixed::operator ==(fixed right)
	{
		return (this->data == right.data) ? 1 : 0;
	}
/* math operators */
	fixed fixed::operator +(fixed right)
	{
		fixed rv;

		rv.data = this->data + right.data;
		return rv;
	}
	fixed fixed::operator +=(fixed right)
	{
		this->data += right.data;
		return this->data;
	}
	fixed fixed::operator -(fixed right)
	{
		fixed rv;

		rv.data = this->data - right.data;
		return rv;
	}
	fixed fixed::operator -=(fixed right)
	{
		this->data -= right.data;
		return this->data;
	}
	fixed fixed::operator *(fixed right)
	{
		fixed rv;

		mul64(&rv.data, this->data, right.data);
		return rv;
	}
	fixed fixed::operator /(fixed right)
	{
		fixed rv;

		div64(&rv.data, this->data, right.data);
		return rv;
	}
	fixed fixed::operator -(void)
	{
		fixed rv;

		rv.data = -this->data;
		return rv;
	}
/* other operators */
/* unused 'int' to make it a postfix operator */
	fixed fixed::operator --(int)
	{
		this->data -= FIXED_MULT;
		return this->data;
	}
/* unused 'int' to make it a postfix operator */
	fixed fixed::operator ++(int)
	{
		this->data += FIXED_MULT;
		return this->data;
	}
	void fixed::operator &=(fixed right)
	{
		this->data &= right.data;
	}
};
/*----------------------------------------------------------------------------
DOS GRAPHICS DEMO USING FIXED-POINT CLASS
----------------------------------------------------------------------------*/
#include <conio.h> /* getch(), outp() */
#include <dos.h> /* MK_FP(), union REGS, int86(), outportb(), pokeb() */

#if defined(__DJGPP__)
#include <sys/farptr.h> /* _farpokeb(), _farpeekb() */
#include <go32.h> /* _dos_ds */
#endif

#if defined(__WATCOMC__)
#define	outportb(P,V)	outp(P,V)
#endif
/*****************************************************************************
*****************************************************************************/
void draw_pixel(fixed x, fixed y, int c)
{
	static const unsigned char mask[] =
	{
		0x80, 0x40, 0x20, 0x10,	0x08, 0x04, 0x02, 0x01
	};
/**/
	unsigned int_x, int_y, offset;

/* set VGA plane based on color */
	outportb(0x3C4, 0x02);
	outportb(0x3C5, c);
/* convert (x,y) to integers, then to framebuffer offset */
	int_x = (unsigned)(x.data >> FRACTION_BITS);
	int_y = (unsigned)(y.data >> FRACTION_BITS);
	offset = int_y * 80 + int_x / 8;
#if defined(__DJGPP__)
	offset += 0xA0000;
	_farpokeb(_dos_ds, offset,
		_farpeekb(_dos_ds, offset) ^ mask[int_x & 7]);
#else
/* bug in Turbo C? this doesn't work:
	pokeb(0xA000, offset, peekb(0xA000, offset) ^ mask[int_x & 7]); */
	*(unsigned char far *)MK_FP(0xA000, offset) ^= mask[int_x & 7];
#endif
}
/*****************************************************************************
Breshenham's algorithm is faster for drawing lines
*****************************************************************************/
#define	ABS(X)	(((X) > 0) ? (X) : (-(X)))
#define	SGN(X)	(((X) > 0) ? 1 : -1)
void draw_line(fixed x1, fixed y1, fixed x2, fixed y2)
{
	fixed len, fixed_delta, int_delta;

/* convert endpoints into deltas */
	x2 -= x1;
	y2 -= y1;
	len = ABS(y2);
/* steep line: step y by +/-1 and x by a fraction < 1
If (len > ABS(x2)) then len must be nonzero,
so there's no divide-by-zero threat */
	if(len > ABS(x2))
	{
		fixed_delta = x2 / len;
		int_delta = SGN(y2);
		for(; len != 0; len--)
		{
			draw_pixel(x1, y1, 1);
			x1 += fixed_delta;
			y1 += int_delta;
		}
	}
/* make sure len is not zero */
	else if(x2 != 0)
/* shallow line: step x by +/-1 and y by a fraction < 1 */
	{
		len = ABS(x2);
		fixed_delta = y2 / len;
		int_delta = SGN(x2);
		for(; len != 0; len--)
		{
			draw_pixel(x1, y1, 1);
			x1 += int_delta;
			y1 += fixed_delta;
		}
	}
}
/*****************************************************************************
recursive divide-and-conquer algorithm is faster for drawing Bezier curves
*****************************************************************************/
void draw_curve(fixed *x, fixed *y)
{
	fixed ax, bx, cx, ay, by, cy;
	fixed xp, yp, t;

	cx = (x[1] - x[0]) * 3;		cy = (y[1] - y[0]) * 3;
	bx = (x[2] - x[1]) * 3 - cx;	by = (y[2] - y[1]) * 3 - cy;
	ax = x[3] - x[0] - bx - cx;	ay = y[3] - y[0] - by - cy;
	for(t = 0; t < 1.0; t = t + 0.005)
	{
		xp = x[0] + t * (cx + t * (bx + t * ax));
		yp = y[0] + t * (cy + t * (by + t * ay));
		draw_pixel(xp, yp, 2);
	}
}
/*****************************************************************************
*****************************************************************************/
int main(void)
{
	fixed fx[4], fy[4];
	union REGS regs;

/* set 640x480 four-plane (16-color) graphics mode */
	regs.x.ax = 0x0012;
	int86(0x10, &regs, &regs);
/* draw a Bezier curve */
	fx[0]=50.0;		fy[0]=50.0;
	fx[1]=50.0;		fy[1]=100.0;
	fx[2]=200.0;		fy[2]=150.0;
	fx[3]=200.0;		fy[3]=200.0;
	draw_curve(fx, fy);
/* draw some lines */
	draw_line(10, 10, 630, 10);
	draw_line(630, 10, 630, 470);
	draw_line(630, 470, 10, 470);
	draw_line(10, 470, 10, 10);

	draw_line(320, 240, 100, 0);
	draw_line(320, 240, 0, 100);
	draw_line(320, 240, 0, 380);
	draw_line(320, 240, 100, 479);
	draw_line(320, 240, 540, 479);
	draw_line(320, 240, 639, 380);
	draw_line(320, 240, 639, 100);
	draw_line(320, 240, 540, 0);
/* await keypress then shut down */
	getch();
	regs.x.ax = 0x0003;
	int86(0x10, &regs, &regs);
	return 0;
}
