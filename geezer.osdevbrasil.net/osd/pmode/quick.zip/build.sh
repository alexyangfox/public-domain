#!/bin/sh
nasm -f bin -o fat12.bin fat12.asm
nasm -f bin -o quick.com quick.asm
umount mnt
umount /dev/fd0
dd bs=1 if=fat12.bin seek=0  count=3   of=/dev/fd0
dd bs=1 if=fat12.bin seek=36 count=476 of=/dev/fd0 skip=36
mount /dev/fd0 mnt
cp -f quick.com mnt/load.bin
umount mnt

