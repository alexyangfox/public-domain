#ifndef __TL_X86_H
#define	__TL_X86_H

#ifdef __cplusplus
extern "C"
{
#endif

unsigned disable(void);
void enable(void);
unsigned char inportb(unsigned port);
void outportb(unsigned port, unsigned val);

#ifdef __cplusplus
}
#endif

#endif

