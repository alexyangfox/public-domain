#ifndef __TL_STDIO_H
#define	__TL_STDIO_H

#ifdef __cplusplus
extern "C"
{
#endif

#include <_va_list.h>
#include <_null.h>
#include <_gcc.h> /* __PRINTF12__, __PRINTF23__ */

int vsprintf(char *buffer, const char *fmt, va_list args);
int sprintf(char *buffer, const char *fmt, ...) __PRINTF23__;

#ifdef __cplusplus
}
#endif

#endif
