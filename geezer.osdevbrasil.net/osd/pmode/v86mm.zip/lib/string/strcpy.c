#include <string.h> /* size_t */
/*****************************************************************************
*****************************************************************************/
char *strcpy(char *dst, const char *src)
{
	char *rv = dst;

	while(1)
	{
		*dst = *src;
		if(*dst == '\0')
			break;
		dst++;
		src++;
	}
	return rv;
}
