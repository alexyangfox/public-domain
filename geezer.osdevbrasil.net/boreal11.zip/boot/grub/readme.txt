GRUB is a GPLed bootloader. See file COPYING for copyright.

Home page:      http://www.gnu.org/software/grub
Binaries:       ftp://alpha.gnu.org/gnu/grub/grub-0.90-i386-pc.tar.gz
Source code:    ftp://alpha.gnu.org/gnu/grub/grub-0.90.tar.gz
HOW-TOs:        http://www.washingdishes.freeuk.com/grubtut.html
		http://my.execpc.com/~geezer/osd/boot/grub-how.txt

The STAGE1 and STAGE2 files in this directory are read-only for
my convenience only (so they don't get trashed by dtou/utod/
todos/fromdos).
