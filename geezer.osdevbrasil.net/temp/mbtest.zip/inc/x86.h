#ifndef __TL_X86_H
#define	__TL_X86_H

#ifdef __cplusplus
extern "C"
{
#endif

void outportb(unsigned port, unsigned val);
unsigned char inportb(unsigned port);

#ifdef __cplusplus
}
#endif

#endif

