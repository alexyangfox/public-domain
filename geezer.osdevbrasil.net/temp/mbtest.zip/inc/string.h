#ifndef __TL_STRING_H
#define	__TL_STRING_H

#ifdef __cplusplus
extern "C"
{
#endif

#define	NULL	0

typedef unsigned size_t;

size_t strlen(const char *str);
void *memcpy(void *dst_ptr, const void *src_ptr, size_t count);
void *memsetw(void *dst_ptr, int val, size_t count);

#ifdef __cplusplus
}
#endif

#endif

