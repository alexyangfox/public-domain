Multiboot-compatible test kernel
Chris Giese <geezer@execpc.com>	http://www.execpc.com/~geezer
Release date: Nov 14, 2003
This code is public domain (no copyright).
You can do whatever you want with it.

This code builds with any of the following flavors of GCC:
    Host OS     GCC type        Build command
    -------     --------        -------------
    DOS         DJGPP           make
    Win32       MinGW           make
    Linux       GCC             make -f linux.mak

After compiling, file KRNL.X contains the kernel. It treats
Multiboot modules as 16-color PCX files and displays them on the
screen. For use with GRUB, you can copy KRNL.X, TEST/LIGHTS.PCX,
and TEST/LEMUR.PCX to the root directory of a bootable GRUB
floppy, and use the following MENU.LST configuration file:
        default 0
        title   MB-TEST
        root    (fd0)
        kernel  /krnl.x
        module  /lights.pcx
        module  /lemur.pcx
