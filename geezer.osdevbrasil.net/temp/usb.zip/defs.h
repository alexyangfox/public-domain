#ifndef DEFS_H
#define	DEFS_H

#ifdef __cplusplus
extern "C"
{
#endif

#if 0
#include <stdint.h>
#else
typedef unsigned char	uint8_t;
typedef unsigned short	uint16_t;
typedef unsigned long	uint32_t;
#endif

#if 1
#define	DEBUG(X)	X
#else
#define	DEBUG(X)	/* nothing */
#endif

#if defined(__TURBOC__)
#include <dos.h> /* FP_SEG(), FP_OFF(), MK_FP(), inport[b](), outport[b]() */
#define	FAR		far
#define	PTR2LINEAR(P)	(FP_SEG(P) * 16uL + FP_OFF(P))
#define	LINEAR2PTR(L)	MK_FP((unsigned)((L) >> 4), (unsigned)((L) & 0x0F))
#define	inportw(P)	inport(P)
#define	outportw(P,V)	outport(P,V)
extern unsigned long far cdecl (*inportl)(unsigned port);
extern void far cdecl (*outportl)(unsigned port, unsigned long val);

#elif defined(__WATCOMC__)&&!defined(__386__)
#include <dos.h> /* FP_SEG(), FP_OFF(), MK_FP() */
#include <conio.h> /* inp[w](), outp[w]() */
#define	FAR		far
#define	PTR2LINEAR(P)	(FP_SEG(P) * 16uL + FP_OFF(P))
#define	LINEAR2PTR(L)	MK_FP((unsigned)(L >> 4), (unsigned)(L & 0x0F))
#define	inportb(P)	inp(P)
#define	inportw(P)	inpw(P)
#define	outportb(P,V)	outp(P,V)
#define	outportw(P,V)	outpw(P,V)
extern unsigned long far cdecl (*inportl)(unsigned port);
extern void far cdecl (*outportl)(unsigned port, unsigned long val);

#elif defined(__WATCOMC__)&&defined(__386__)
#include <conio.h> /* inp[w](), outp[w]() */
#define	FAR		/* nothing */
#define	PTR2LINEAR(P)	((unsigned long)(P)) /* CauseWay DOS extender only? */
#define	LINEAR2PTR(L)	((void *)(L)) /* CauseWay DOS extender only? */
#define	inportb(P)	inp(P)
#define	inportw(P)	inpw(P)
#define	outportb(P,V)	outp(P,V)
#define	outportw(P,V)	outpw(P,V)
#define	inportl(P)	inpd(P)
#define	outportl(P,V)	outpd(P,V)

#elif defined(__DJGPP__)
#define	__386__		1
#include <sys/nearptr.h> /* __djgpp_conventional_base */
#include <dos.h> /* inport[b|w|l](), outport[b|w|l]() */
#define	FAR		/* nothing */
#define	PTR2LINEAR(P)	((unsigned long)(P) - __djgpp_conventional_base)
#define	LINEAR2PTR(L)	((void *)((unsigned)(L) + __djgpp_conventional_base))

#else
#error Sorry, unsupported compiler
#endif

#define MIN(X, Y)	(((X) < (Y)) ? (X) : (Y))

/* xxx - this should be private to PCI.C */
typedef struct
{
	unsigned char bus, dev, fn;
} pci_t;

extern int g_debug;

void dump(void FAR *data_p, unsigned count);

#ifdef __cplusplus
}
#endif

#endif /* ndef DEFS_H */
