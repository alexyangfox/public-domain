/*----------------------------------------------------------------------------
UHCI CODE

EXPORTS:
int uhci_detect(void);
int uhci_init(void);
void uhci_display_port_status(void);
int uhci_control_transaction(unsigned adr,
		unsigned endpoint0_max_packet_size, void FAR *setup_data_ptr,
		unsigned setup_len, void FAR *data_ptr, unsigned data_len);
----------------------------------------------------------------------------*/
#include <stdlib.h> /* atexit(), calloc(), free() */
#include <string.h> /* memset() */
#include <stdio.h> /* printf() */
#include "defs.h"

/* IMPORTS
from PCI.C */
int pci_detect(void);
int pci_read_config_byte(pci_t *pci, unsigned reg, unsigned char *val);
int pci_read_config_dword (pci_t *pci, unsigned reg, unsigned long *val);
int pci_iterate(pci_t *pci);

/* from MISC.C */
void FAR *alloc_dma_mem(int *handle, unsigned size, unsigned align);
void free_dma_mem(int handle);

/* packet IDs. If the actual packet ID value is 'pid', these values are
	((~pid << 4) & 0xF0) | (pid & 0x0F)
The other 14 PID types are generated and managed only by the hardware. */
#define	USB_PID_OUT		0xE1
#define	USB_PID_IN		0x69
#define	USB_PID_SETUP		0x2D

/* I tried bitfields in td_t, but that's also awkward.
There's no elegant way to do this... */
#define	TD_DWORD2(PID, ADR, ENDP, D, MAX_LEN)			\
	 (((unsigned long)(PID)		 &  0xFF) <<  0) |	\
	 (((unsigned long)(ADR)		 &  0x7F) <<  8) |	\
	 (((unsigned long)(ENDP)	 &  0x0F) << 15) |	\
	 (((unsigned long)(D)		 &  0x01) << 19) |	\
	((((unsigned long)(MAX_LEN) - 1) & 0x7FF) << 21)

/* 32-byte UHCI transfer descriptor (TD) */
#pragma pack(1)
typedef struct
{
/* bytes 0-3 */
	uint32_t link;
/* bytes 4-7
b15-b11=reserved, b10-b0=(actual data length - 1) */
	uint16_t act_len;
/* error-related status bits. b7=Active.
I was using bitfields here, but Watcom C didn't work with those. */
	volatile uint8_t status;
/* various other bits. b4-b3=retry count */
	uint8_t flags;
/* bytes 8-11. Lotta stuff here (see the TD_DWORD2) macro above):
b21-b3=max_len, b20=reserved, b19=DATA1, b18-b15=endpoint,
b14-b8=device address, b7-b0=packet ID */
	uint32_t dword2;
/* bytes 12-15 */
	uint32_t buf_ptr;	/* linear address */
/* bytes 16-31. YES, you need these -- even though they're not used. */
	char res[16];
} td_t;

/* 8-byte UHCI queue head (QH) */
typedef struct
{
/* bytes 0-3: pointer to next horizontal object in schedule
b3-b2=reserved, b1=next object is QH, b0=Terminate  */
	uint32_t h;
/* bytes 4-7: pointer to next vertical object in schedule
b3-b2=reserved, b1=next object is QH, b0=Terminate */
	uint32_t v;
} qh_t;

static unsigned g_io_adr;
static uint32_t FAR *g_queue_head;
/*****************************************************************************
*****************************************************************************/
int uhci_detect(void)
{
	uint32_t i, j;
	uint8_t k;
	pci_t pci;
	int err;

/* check for PCI BIOS */
	if(pci_detect())
		return -1;
/* find a USB controller */
	printf("USB controller...");
	memset(&pci, 0, sizeof(pci));
	do
	{
/* pci_byte[8]=revision ID, pci_byte[9]=programming interface
(registers), pci_byte[10]=sub-class, pci_byte[11]=class */
		err = pci_read_config_dword(&pci, 0x08, &j);
		if(err)
ERR:		{
			printf("Error 0x%02X reading PCI config\n", err);
			return -1;
		}
/* class=12=0x0C=serial bus controller; sub-class=3=0x03=USB */
		if((j & 0xFFFF0000L) == 0x0C030000L)
			goto OK;
	} while(!pci_iterate(&pci));
	printf("not found\n");
	return -1;
OK:
	printf("found ");
/* 00=PCI_VENDOR_ID */
err = pci_read_config_dword(&pci, 0x00, &i);
if(err)
 goto ERR;
printf(" (vendorID=%04lX, deviceID=%04lX", i & 0xFFFF, i >> 16);
/* interface: 0x00=UHCI, 0x10=OHCI, 0x20=EHCI (USB 2.x),
0x80=other HCD, 0xFE=not an HCD */
	k = (j >> 8) & 0xFF;
	printf(", interface=%02X)\n", k);
	if(k != 0)
	{
		printf("Error: this code supports only UHCI USB\n");
		return -1;
	}
/* get I/O address by reading base address register (BAR) 4 */
	err = pci_read_config_dword(&pci, 0x20, &i);
	if(err)
		goto ERR;
/* b0 indicates I/O-mapped I/O */
	i &= ~0x01L;
	printf("\tI/O adr=0x%lX\n", i);
	g_io_adr = (unsigned)i;
/* USB spec version.
### - do I need this? to tell USB 1.x from USB 2.x? */
err = pci_read_config_byte(&pci, 0x60, &k);
if(err)
 goto ERR;
printf("\tUSB version %u.%u\n", k >> 4, k & 0x0F);

/* clear Master Abort; since I keep getting it */
//err = pci_write_config_word(&pci, 0x06, 0x2000);
//if(err)
// goto ERR;

/* dump command and status registers */
//err = pci_read_config_dword(&pci, 0x04, &i);
//if(err)
// goto ERR;
/* want bus-master enabled
0x0005: b0=I/O enabled, b2=bus master enabled */
//printf("PCI command register=%04lX\n", i & 0xFFFF);
/* 0x2280: b7=fast back-to-back capable, b9=medium device select timing,
b13=received master abort */
//printf("PCI  status register=%04lX\n", i >> 16);
	return 0;
}
/*****************************************************************************
*****************************************************************************/
static void uhci_exit(void)
{
/* USBCMD register - shut down controller */
	outportw(g_io_adr + 0, 0x0000);
}
/*****************************************************************************
*****************************************************************************/
int uhci_init(void)
{
	uint32_t fl_linear, qh_linear, td_linear, FAR *fl;
	unsigned timeout;
	td_t FAR *td;
	qh_t FAR *qh;
	int i;

/* These allocations are not freed -- don't bother saving the handle.
Frame List (FL) -- 4096 bytes aligned on 4096-byte boundary */
	fl = (uint32_t FAR *)alloc_dma_mem(&i, 4096, 4096);
	if(fl == NULL)
		return -1;
/* Queue Heads (QHs) -- 16 bytes each, aligned on 16-byte boundary */
	qh = (qh_t FAR *)alloc_dma_mem(&i, sizeof(qh_t) * 2, 16);
	if(qh == NULL)
		return -1;
/* Transfer Descriptor (TD) -- 32 bytes, aligned on 16-byte boundary */
	td = (td_t FAR *)alloc_dma_mem(&i, sizeof(td_t) * 1, 16);
	if(td == NULL)
		return -1;
/* init dummy TD to stop the PIIX USB controller from going berserk */
	td_linear = PTR2LINEAR(td);
	td[0].link = 0x00000001L;		/* b0=1: terminate */
/* init QHs */
	qh_linear = PTR2LINEAR(qh);
/* horizontal chain: QH[0] --> QH[1] */
	qh[0].h = (qh_linear +
		sizeof(qh_t) * 1) | 0x00000002L;/* b1=1: points to QH */
/* first vertical chain: nothing yet, but save the address.
We'll put a pointer to a chain of TDs here later. */
	qh[0].v  = 0x00000001L;			/* b0=1: terminate */
	g_queue_head = &qh[0].v;
/* second vertical chain: QH[1] --> dummy TD */
	qh[1].h = 0x00000001L;			/* b0=1: terminate */
	qh[1].v  = td_linear;
/* init FL */
	fl_linear = PTR2LINEAR(fl);
	for(i = 0; i < 1024; i++)
		fl[i] = qh_linear | 0x00000002L;/* b1=1: points to a QH */

/* debug dumps */
printf("Linear address of Frame List (FL)=0x%lX\n", fl_linear);
printf("\tFL[n]=0x%lX\n", fl[0]);
/* FL[0] should point to QH array */
printf("Linear address of Queue Heads (QHs)=0x%lX\n", qh_linear);
printf("\tQH[0].h=0x%08lX, QH[1].h=0x%08lX\n", qh[0].h, qh[1].h);
printf("\tQH[0].v=0x%08lX, QH[1].v=0x%08lX\n", qh[0].v, qh[1].v);
/* QH[1].v should point to dummy TD */
printf("Linear address of dummy Transfer Descriptor (TD)=0x%lX\n", td_linear);

/* reset everything (USB host controller chip and the buss) */
printf("Resetting USB controller...\n");
	outportw(g_io_adr + 0, 0x0004); 	/* b2=1: RESET */
	delay(20);
	outportw(g_io_adr + 0, 0x0000);
	delay(20);
/* PORT 1 & 2 STATUS/CONTROL REGISTERS - enable the ports */
	outportw(g_io_adr + 16, 0x008F);
	outportw(g_io_adr + 18, 0x008F);
/* wait up to 1 second */
	for(timeout = 1000; timeout != 0; timeout--)
	{
		unsigned port1, port2;

		port1 = inportw(g_io_adr + 16);
		port2 = inportw(g_io_adr + 18);
printf("port1 S/C=0x%04X; port2 S/C=0x%04X\r", port1, port2);
/* want b0=1 (device connected) and b2=1 (device enabled) */
		if((port1 & 0x0005) == 0x0005)
			break;
		if((port2 & 0x0005) == 0x0005)
			break;
		delay(1);
	}
printf("\n");
	if(timeout == 0)
	{
		printf("No USB device connected to this PC\n");
		return -1;
	}
/* SOFMOD register - USB frame rate fine-tuning */
	outportb(g_io_adr + 12, 0x40);
/* FRBASEADD register - write linear address of Frame List */
	outportl(g_io_adr + 8, fl_linear);
/* FRNUM register - zero the Frame Number counter */
	outportw(g_io_adr + 6, 0x0000);
/* USBCMD register - set b0 to start controller; i.e. GO! */
	outportw(g_io_adr + 0, 0x0001);
/* stop controller when this program exits */
	atexit(uhci_exit);
	return 0;
}
/*****************************************************************************
*****************************************************************************/
void uhci_display_port_status(void)
{
	char comma;
	int i;

	i = inportw(g_io_adr + 16) & ~0x0030;
	printf("\tUSB port 1 status=0x%02X:", i);
	comma = ' ';
	if(i & 0x1000)
	{
		printf("%c suspended", comma);
		comma = ',';
	}
	if(i & 0x0200)
	{
		printf("%c reset", comma);
		comma = ',';
	}
	if(i & 0x0100)
	{
		printf("%c low-speed device attached", comma);
		comma = ',';
	}
	if(i & 0x0004)
	{
		printf("%c enabled", comma);
		comma = ',';
	}
	if(i & 0x0001)
		printf("%c device connected", comma);

	i = inportw(g_io_adr + 18) & ~0x0030;
	printf("\n\tUSB port 2 status=0x%02X:", i);
	comma = ' ';
	if(i & 0x1000)
	{
		printf("%c suspended", comma);
		comma = ',';
	}
	if(i & 0x0200)
	{
		printf("%c reset", comma);
		comma = ',';
	}
	if(i & 0x0100)
	{
		printf("%c low-speed device attached", comma);
		comma = ',';
	}
	if(i & 0x0004)
	{
		printf("%c enabled", comma);
		comma = ',';
	}
	if(i & 0x0001)
		printf("%c device connected", comma);
	putchar('\n');
}
/*****************************************************************************
*****************************************************************************/
#include <conio.h>

int uhci_control_transaction(unsigned adr, unsigned endpoint0_max_packet_size,
		unsigned char FAR *setup_data, unsigned setup_len,
		unsigned char FAR *data, unsigned data_len)
{
/* endpoint is always #0 for control transactions */
	static const unsigned endp = 0;
/**/
	unsigned num_tds, i, j;
	int td_mem_handle, err;
	uint32_t td_linear;
	char data1, dir;
	td_t FAR *td;

/* total number of TDs required */
	num_tds = (data_len + endpoint0_max_packet_size - 1) /
		endpoint0_max_packet_size + 2;
/* allocate memory for TDs */
	td = (td_t FAR *)alloc_dma_mem(&td_mem_handle,
		sizeof(td_t) * num_tds, 16);
	if(td == NULL)
		return -1;
	td_linear = PTR2LINEAR(td);
/* build token TD
dword #0 */
	td[0].link = (td_linear +		/* b2=1: depth-first */
		sizeof(td_t) * 1) | 0x00000004L;
/* dword #1 (status) */
	td[0].act_len = setup_len - 1;
	td[0].status = 0x80;			/* b7=1: Active */
	td[0].flags = 0x18;			/* b4-b3=3: retry count */
/* dword #2 (token/destination) */
	td[0].dword2 =TD_DWORD2(USB_PID_SETUP, adr, endp, 0, setup_len);
/* dword #3 (buffer) */
	td[0].buf_ptr = PTR2LINEAR(setup_data);
	DEBUG(
		if(g_debug)
		{
			printf("Linear address of setup packet=0x%lX\n",
				PTR2LINEAR(setup_data));
			printf("    Hex dump of setup packet:\n");
			dump(setup_data, setup_len);
		}
	)
/* build data TDs */
	data1 = 1;
	dir = (setup_data[0] & 0x80) ? USB_PID_IN : USB_PID_OUT;
	for(i = 1; i < num_tds - 1; i++)
	{
		td[i].link = (td_linear +	/* b2=1: depth-first */
			sizeof(td_t) * (i + 1)) | 0x00000004L;
		j = MIN(data_len, endpoint0_max_packet_size);
		td[i].act_len = j - 1;
		td[i].status = 0x80;		/* b7=1: Active */
		td[i].flags = 0x18;		/* b4-b3=3: retry count */
		td[i].dword2 = TD_DWORD2(dir, adr, endp, data1, j);
		td[i].buf_ptr = PTR2LINEAR(data);

		data_len -= j;
// xxx - if you're going to be doing math on this pointer,
// then FAR should probably be declared as 'huge'
		data += j;
		data1 = data1 ? 0 : 1;
	}
/* build handshake TD */
	dir = (dir == USB_PID_IN) ? USB_PID_OUT : USB_PID_IN;
	td[num_tds - 1].link = 0x00000001L;	/* b0=1: terminate */
	td[num_tds - 1].act_len = 0x7FF;	/* =0 (no data) */
	td[num_tds - 1].status = 0x80;		/* b7=1: Active */
	td[num_tds - 1].flags = 0x18;		/* b4-b3=3: retry count */
	td[num_tds - 1].dword2 = TD_DWORD2(dir, adr, endp, 1, 0);
	DEBUG(
		if(g_debug)
		{
			printf("Linear address of TDs=0x%lX\n", td_linear);
			printf("    Hex dump of TDs:\n");
			for(i = 0; i < num_tds; i++)
				dump(&td[i], 16);
		}
	)
/* add our chain of TDs to the Queue Head */
	*g_queue_head = td_linear;
/* now poll the TDs as the hardware processes them */
	err = 0;
	for(i = 0; i < num_tds; )
	{
/* press a key to abort if it hangs... */
if(kbhit()) { err = 1; break; }
		if(td[i].status & 0x80)
			continue;
		if(td[i].status != 0)
		{
			printf("UHCI control transfer failed (descriptor "
				"#%u/%u, status=0x%02X)\n", i + 1,
				num_tds, td[i].status);
			err = -1;
			break;
		}
/* current TD was processed successfully; advance to next TD */
		i++;
	}
	DEBUG(
		if(g_debug)
		{
			printf("    Hex dump of TDs:\n");
			for(i = 0; i < num_tds; i++)
				dump(&td[i], 16);
		}
	)
	free_dma_mem(td_mem_handle);
	return err;
}
/*****************************************************************************
*****************************************************************************/
#if 0
int uhci_bulk_input(unsigned adr, unsigned endpoint,
		unsigned max_packet_size, void FAR *data_ptr,
		unsigned data_len)
{
	unsigned char FAR *data = data_ptr;

// xxx - if you're going to be doing math on this pointer,
// then FAR should probably be declared as 'huge'
//		data += j;
}
#endif
