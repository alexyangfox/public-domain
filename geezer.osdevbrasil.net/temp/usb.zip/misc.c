/*----------------------------------------------------------------------------
EXPORTS:
void dump(void FAR *data_p, unsigned count);
void FAR *alloc_dma_mem(int *handle, unsigned size, unsigned align);
void free_dma_mem(int handle);

extern int g_debug;
extern unsigned long far cdecl (*inportl)(unsigned port);
extern void far cdecl (*outportl)(unsigned port, unsigned long val);
----------------------------------------------------------------------------*/
#include <stdlib.h> /* calloc(), free() */
#include <stdio.h> /* printf() */
#if defined(__DJGPP__)
#include <dpmi.h> /* __dpmi_...() */
#endif
#include "defs.h"

int g_debug;
/*****************************************************************************
*****************************************************************************/
#define BPERL		16	/* byte/line for dump */

void dump(void FAR *data_p, unsigned count)
{
	unsigned char FAR *data = (unsigned char FAR *)data_p;
	unsigned byte1, byte2;

	while(count != 0)
	{
		printf("    ");
		for(byte1 = 0; byte1 < BPERL; byte1++)
		{
			if(count == 0)
				break;
			printf("%02X ", data[byte1]);
			count--;
		}
		printf("\t");
		for(byte2 = 0; byte2 < byte1; byte2++)
		{
			if(data[byte2] < ' ')
				printf(".");
			else
				printf("%c", data[byte2]);
		}
		printf("\n");
		data += BPERL;
	}
}
/*****************************************************************************
These functions are _code_, but are stored in the _data_ segment.
Declare them 'far' and end them with 'retf' instead of 'ret'

For 16-bit Watcom C, use 'cdecl' to force usage of normal, stack
calling convention instead of Watcom register calling convention.
*****************************************************************************/
#if defined(__TURBOC__) || (defined(__WATCOMC__)&&!defined(__386__))
static const unsigned char g_inportl[] =
{
	0x55,			/* push bp */
	0x8B, 0xEC,		/*  mov bp,sp */
	0x8B, 0x56, 0x06,	/*  mov dx,[bp + 6] */
	0x66, 0xED,		/*  in eax,dx */
	0x8B, 0xD0,		/*  mov dx,ax */
	0x66, 0xC1, 0xE8, 0x10,	/*  shr eax,16 */
	0x92,			/*  xchg dx,ax */
	0x5D,			/* pop bp */
	0xCB			/* retf */
};

unsigned long far cdecl (*inportl)(unsigned port) =
	(unsigned long far (*)(unsigned))g_inportl;
/*****************************************************************************
*****************************************************************************/
static const unsigned char g_outportl[] =
{
	0x55,			/* push bp */
	0x8B, 0xEC,		/*  mov bp,sp */
	0x8B, 0x56, 0x06,	/*  mov dx,[bp + 6] */
	0x66, 0x8B, 0x46, 0x08,	/*  mov eax,[bp + 8] */
	0x66, 0xEF,		/*  out dx,eax */
	0x5D,			/* pop bp */
	0xCB			/* retf */
};

void far cdecl (*outportl)(unsigned port, unsigned long val) =
	(void far (*)(unsigned, unsigned long))g_outportl;
#endif
/*****************************************************************************
*****************************************************************************/
#if defined(__WATCOMC__)&&defined(__386__)
#include <string.h> /* memset() */
#include <dos.h> /* union REGS, int386() */

static int __dpmi_allocate_dos_memory(unsigned paragraphs, int *sel)
{
	union REGS regs;

	memset(&regs, 0, sizeof(regs));
	regs.w.ax = 0x0100;
	regs.w.bx = paragraphs;
	int386(0x31, &regs, &regs);
	*sel = regs.w.dx;
	return regs.w.cflag ? -1 : regs.w.ax;
}
/*****************************************************************************
*****************************************************************************/
static int __dpmi_free_dos_memory(int sel)
{
	union REGS regs;

	memset(&regs, 0, sizeof(regs));
	regs.w.ax = 0x0101;
	regs.w.dx = sel;
	int386(0x31, &regs, &regs);
	return regs.w.cflag ? -1 : regs.w.ax;
}
#endif
/*****************************************************************************
Allocates conventional memory for use by PCI DMA.
Under DPMI, conventional memory is:
- Physically contiguous,
- Mapped 1:1 (virtual address = physical address), and
- Unpaged
*****************************************************************************/
void FAR *alloc_dma_mem(int *handle, unsigned size, unsigned align)
{
	uint32_t linear;
	void FAR *ptr;
	unsigned len;
#if defined(__386__)
	int i;
#endif

/* 'align' must be a power of 2 */
	if(align & (align - 1))
	{
		printf("Error in alloc_dma_mem: align must be a power of 2\n");
		return NULL;
	}
/* round up length to achieve desired alignment */
	if(align >= 16)
		len = size + align - 1;
	else
		len = size + 15;
#if defined(__386__)
/* DJGPP and 32-bit Watcom C */
	i = __dpmi_allocate_dos_memory(len / 16, handle);
	if(i == -1)
	{
		printf("Error: can't allocate conventional memory\n");
		return NULL;
	}
	linear = i * 16uL;
/* align */
	if(align != 0)
		linear = (linear + align - 1) & -(uint32_t)align;
/* convert to pointer */
	ptr = LINEAR2PTR(linear);
	memset(ptr, 0, size);
	return ptr;
#else
/* Turbo C and 16-bit Watcom C */
	ptr = calloc(len, 1);
	if(ptr == NULL)
	{
		printf("Error: can't allocate conventional memory\n");
		return ptr;
	}
	*handle = (int)ptr;
/* convert to linear */
	linear = PTR2LINEAR(ptr);
/* align */
	if(align != 0)
		linear = (linear + align - 1) & -(uint32_t)align;
/* convert back to pointer */
	return LINEAR2PTR(linear);
#endif
}
/*****************************************************************************
*****************************************************************************/
void free_dma_mem(int handle)
{
#if defined(__386__)
	__dpmi_free_dos_memory(handle);
#else
	free((void *)handle);
#endif
}
