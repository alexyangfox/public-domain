USB demo code for DOS
Chris Giese     <geezer@execpc.com>     http://my.execpc.com/~geezer
Release date: September 24, 2007
This code is public domain (no copyright).
You can do whatever you want with it.

Things that work:
- UHCI
- DJGPP, Turbo C++ 1.0, Turbo C++ 3.0 with optimizations turned off,
  Borland C++ 3.1, 16-bit Watcom C 11.0c, and 32-bit Watcom C 11.0c
  with CauseWay DOS extender
- Control (SETUP) transfers

Things I'm working on:
- Bulk IN transfers
- Still a bit unreliable -- the trouble is probably near the random
  delay() calls during reset in UHCI.C

Things not implemented:
- EHCI (USB 2.x) and OHCI
- Isochronous, interrupt, and bulk OUT transfers
- Hotplug
- Hubs
- Support for various device "classes"

To do:
- Support multiple USB devices connected to the port(s)
- Experiment with USB devices other than the camera

- In usb_display_string(), the first call to usb_control_transaction()
  returns bogus data (data is one byte -- too short?)

- uhci_control_transaction() needs a timeout (why? was it naughty? :)
