/*----------------------------------------------------------------------------
PCI CODE

EXPORTS:
int pci_detect(void);
int pci_read_config_byte(pci_t *pci, unsigned reg, unsigned char *val);
int pci_read_config_word(pci_t *pci, unsigned reg, unsigned short *val);
int pci_read_config_dword (pci_t *pci, unsigned reg, unsigned long *val);
int pci_write_config_byte(pci_t *pci, unsigned reg, unsigned val);
int pci_write_config_word(pci_t *pci, unsigned reg, unsigned val);
int pci_write_config_dword(pci_t *pci, unsigned reg, unsigned long val);
int pci_iterate(pci_t *pci);
----------------------------------------------------------------------------*/
#include <stdio.h> /* printf() */
#include "defs.h"

#define PCI_READ_CONFIG_BYTE	0xB108
#define PCI_READ_CONFIG_WORD	0xB109
#define PCI_READ_CONFIG_DWORD	0xB10A
#define PCI_WRITE_CONFIG_BYTE	0xB10B
#define PCI_WRITE_CONFIG_WORD	0xB10C
#define PCI_WRITE_CONFIG_DWORD	0xB10D

#define	PCI_ADR_REG		0xCF8
#define	PCI_DATA_REG		0xCFC
/*****************************************************************************
If you have PnP code available, device PNP0A03 also
indicates the presence of a PCI controller in the system.
*****************************************************************************/
int pci_detect(void)
{
	printf("PCI controller...");
/* poke 32-bit I/O register at 0xCF8 to see if
there's a PCI controller there */
	outportl(PCI_ADR_REG, 0x80000000L); /* bus 0, dev 0, fn 0, reg 0 */
	if(inportl(PCI_ADR_REG) != 0x80000000L)
	{
		printf("not found\n");
		return -1;
	}
	printf("found\n");
	return 0;
}
/*****************************************************************************
*****************************************************************************/
int pci_read_config_byte(pci_t *pci, unsigned reg,
		unsigned char *val)
{
	outportl(PCI_ADR_REG,
		0x80000000L | /* "enable configuration space mapping" */
		((unsigned long)pci->bus << 16) |	/* b23-b16=bus */
		((unsigned)pci->dev << 11) |		/* b15-b11=dev */
		((unsigned)pci->fn << 8) |		/* b10-b8 =fn  */
		(reg & ~3));				/* b7 -b2 =reg */
	*val = inportb(PCI_DATA_REG + (reg & 3));// ### - is this legit?
	return 0;
}
/*****************************************************************************
*****************************************************************************/
int pci_read_config_word(pci_t *pci, unsigned reg,
		unsigned short *val)
{
	outportl(PCI_ADR_REG, 0x80000000L |
		((unsigned long)pci->bus << 16) |
		((unsigned)pci->dev << 11) |
		((unsigned)pci->fn << 8) | (reg & ~3));
	*val = inportw(PCI_DATA_REG + (reg & 2));
	return 0;
}
/*****************************************************************************
*****************************************************************************/
int pci_read_config_dword (pci_t *pci, unsigned reg,
		unsigned long *val)
{
	outportl(PCI_ADR_REG, 0x80000000L |
		((unsigned long)pci->bus << 16) |
		((unsigned)pci->dev << 11) |
		((unsigned)pci->fn << 8) | (reg & ~3));
	*val = inportl(PCI_DATA_REG + 0);
	return 0;
}
/*****************************************************************************
*****************************************************************************/
int pci_write_config_byte(pci_t *pci, unsigned reg,
		unsigned val)
{
	outportl(PCI_ADR_REG, 0x80000000L |
		((unsigned long)pci->bus << 16) |
		((unsigned)pci->dev << 11) |
		((unsigned)pci->fn << 8) | (reg & ~3));
	outportb(PCI_DATA_REG + (reg & 3), val);
	return 0;
}
/*****************************************************************************
*****************************************************************************/
int pci_write_config_word(pci_t *pci, unsigned reg,
		unsigned val)
{
	outportl(PCI_ADR_REG, 0x80000000L |
		((unsigned long)pci->bus << 16) |
		((unsigned)pci->dev << 11) |
		((unsigned)pci->fn << 8) | (reg & ~3));
	outportw(PCI_DATA_REG + (reg & 2), val);
	return 0;
}
/*****************************************************************************
*****************************************************************************/
int pci_write_config_dword(pci_t *pci, unsigned reg,
		unsigned long val)
{
	outportl(PCI_ADR_REG, 0x80000000L |
		((unsigned long)pci->bus << 16) |
		((unsigned)pci->dev << 11) |
		((unsigned)pci->fn << 8) | (reg & ~3));
	outportl(PCI_DATA_REG + 0, val);
	return 0;
}
/*****************************************************************************
*****************************************************************************/
int pci_iterate(pci_t *pci)
{
	unsigned char hdr_type = 0x80;

/* if first function of this device, check if multi-function device
(otherwise fn==0 is the _only_ function of this device) */
	if(pci->fn == 0)
	{
		if(pci_read_config_byte(pci, 0x0E, &hdr_type))
			return -1;	/* error */
	}
/* increment iterators
fn (function) is the least significant, bus is the most significant */
	pci->fn++;
	if(pci->fn >= 8 || (hdr_type & 0x80) == 0)
	{
		pci->fn = 0;
		pci->dev++;
		if(pci->dev >= 32)
		{
			pci->dev = 0;
			pci->bus++;
//			if(pci->bus > g_last_pci_bus)
			if(pci->bus > 7)
				return 1; /* done */
		}
	}
	return 0;
}
