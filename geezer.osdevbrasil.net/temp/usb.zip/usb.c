/*----------------------------------------------------------------------------
USB CODE

EXPORTS:
int usb_enumerate(void);
----------------------------------------------------------------------------*/
#include <stdlib.h> /* NULL, free() */
#include <string.h> /* memset() */
#include <stdio.h> /* putchar(), printf() */
#include "defs.h"

/* IMPORTS
from UHCI.C */
int uhci_detect(void);
int uhci_init(void);
void uhci_display_port_status(void);
int uhci_control_transaction(unsigned adr,
		unsigned endpoint0_max_packet_size, void FAR *setup_data_ptr,
		unsigned setup_len, void FAR *data_ptr, unsigned data_len);

/* from MISC.C */
void FAR *alloc_dma_mem(int *handle, unsigned size, unsigned align);
void free_dma_mem(int handle);

/* standard USB requests */
#define	USB_REQ_GET_STATUS	0
#define	USB_REQ_CLEAR_FEATURE	1
//
#define	USB_REQ_SET_FEATURE	3
//
#define	USB_REQ_SET_ADDRESS	5
#define	USB_REQ_GET_DESCRIPTOR	6
#define	USB_REQ_SET_DESCRIPTOR	7
#define	USB_REQ_GET_CONFIG	8
#define	USB_REQ_SET_CONFIG	9
#define	USB_REQ_GET_INTERFACE	10
#define	USB_REQ_SET_INTERFACE	11
#define	USB_REQ_SYNCH_FRAME	12

/* descriptor types */
#define	USB_DTYPE_DEVICE	1
#define	USB_DTYPE_CONFIG	2
#define	USB_DTYPE_STRING	3
#define	USB_DTYPE_INTERFACE	4 /* "Not directly accessible" */
#define	USB_DTYPE_ENDPOINT	5 /* "Not directly accessible" */
#define	USB_DTYPE_QUALIFIER	6 /* high-speed USB only */
#define	USB_DTYPE_SPEED_CONFIG	7 /* high-speed USB only */
#define	USB_DTYPE_IFACE_POWER	8 /* obsolete */
#define	USB_DTYPE_OTG		9 /* On-The-Go; not directly accessible */

/* USB endpoint info */
typedef struct
{						/* descriptor offset: */
/* b7=IN/!OUT, b3-b0=endpoint number */
	unsigned char adr;				/* 2 */
	unsigned char attrib;				/* 3 */
	unsigned max_packet_size;			/* 4-5 */
	unsigned polling_interval; /* usec */		/* 6 */
} usb_endp_t;

/* USB interface info */
typedef struct
{						/* descriptor offset: */
	unsigned char iface_num;			/* 2 */
	unsigned char alt;	/* ? */			/* 3 */
	unsigned char num_endp;				/* 4 */
/* "class" is a C++ reserved word */
	unsigned char _class, subclass, proto;		/* 5,6,7 */
	unsigned char iface_string;			/* 8 */
/* endpoints for this interface */
	usb_endp_t *endp;
} usb_iface_t;

/* USB configuration info */
typedef struct
{						/* descriptor offset: */
	unsigned char num_ifs;				/* 4 */
	unsigned char config_num;			/* 5 */
	unsigned char config_string;			/* 6 */
	unsigned char attrib;				/* 7 */
	unsigned max_current;	/* in mA */		/* 8 */
/* interfaces for this config */
	usb_iface_t *iface;
} usb_config_t;

/* USB descriptor info */
typedef struct
{						/* descriptor offset: */
	unsigned char adr; /* assigned by this code */
	unsigned char usb_ver_major, usb_ver_minor;	/* 2,3 */
	unsigned char _class, subclass, proto;		/* 4,5,6 */
	unsigned char endpoint0_max_packet_size;	/* 7 */
	unsigned vendor_id, product_id;			/* 8-9,10-11 */
	unsigned char mfgr_string;			/* 14 */
	unsigned char prod_string;			/* 15 */
	unsigned char sernum_string; 			/* 16 */
	unsigned num_configs;				/* 17 */
/* configurations for this device */
	usb_config_t *configs;
} usb_dev_t;
/*****************************************************************************
*****************************************************************************/
static void usb_destroy_dev(usb_dev_t *dev)
{
	unsigned c_num, i_num;
	usb_config_t *c;
	usb_iface_t *i;

	if(dev->configs != NULL && dev->num_configs != 0)
	{
/* for each config in device... */
		for(c_num = 0; c_num < dev->num_configs; c_num++)
		{
			c = &dev->configs[c_num];
			if(c->iface != NULL && c->num_ifs != 0)
			{
/* for each interface in config... */
				for(i_num = 0; i_num < c->num_ifs; i_num++)
				{
					i = &c->iface[i_num];
/* free endpoints */
					if(i->endp != NULL)
						free(i->endp);
				}
/* free interfaces */
				free(c->iface);
			}
		}
/* free configs */
		free(dev->configs);
	}
	memset(dev, 0, sizeof(usb_dev_t));
}
/*****************************************************************************
could write your own OHCI or EHCI code and call it from here...
*****************************************************************************/
static int usb_control_transaction(usb_dev_t *dev, void FAR *setup_data_ptr,
		unsigned setup_len, void FAR *data_ptr, unsigned data_len)
{
	return uhci_control_transaction(dev->adr,
		dev->endpoint0_max_packet_size, setup_data_ptr,
		setup_len, data_ptr, data_len);
}
/*****************************************************************************
This function will fail if desc_type==USB_DTYPE_INTERFACE or desc_type==
USB_DTYPE_ENDPOINT. ("USB Made Simple" calls them "Not directly accessible".)
To get these descriptors:
1. Load the config descriptor
2. Look at bytes 2-3 of the config descriptor. This is the combined
   length of the config descriptor and its subordinate interface and
   endpoint descriptors.
3. Load this entire mass of descriptors (config, interface, and
   endpoint) into memory, then pick out what you need
*****************************************************************************/
static int usb_get_descriptor(usb_dev_t *dev, unsigned desc_type,
		unsigned desc_index, unsigned desc_len, void FAR *data)
{
	unsigned char FAR *setup;
	int mem_handle, i;

	setup = (unsigned char FAR *)alloc_dma_mem(&mem_handle, 8, 1);
	if(setup == NULL)
		return -1;
	setup[0] = 0x80;
	setup[1] = USB_REQ_GET_DESCRIPTOR;/* bRequest, =6 */
	setup[2] = desc_index; 		/* wValue LSB: descriptor index */
	  setup[3] = desc_type;		/* wValue MSB: descriptor type */
	setup[4] = setup[5] = 0;	/* wIndex: zero or language ID */
	setup[6] = desc_len;		/* wLength: descriptor length */
	  setup[7] = 0;
	i = usb_control_transaction(dev, setup, 8, data, desc_len);
	free_dma_mem(mem_handle);
	return i;
}
/*****************************************************************************
*****************************************************************************/
static int usb_set_address(usb_dev_t *dev, unsigned adr)
{
	unsigned char FAR *setup;
	int mem_handle, i;

	setup = (unsigned char FAR *)alloc_dma_mem(&mem_handle, 8, 1);
	if(setup == NULL)
		return -1;
	setup[0] = 0;
	setup[1] = USB_REQ_SET_ADDRESS;	/* bRequest, =5 */
	setup[2] = adr;			/* wValue */
	 setup[3] = 0;
	setup[4] = setup[5] = 0;	/* wIndex */
	setup[6] = setup[7] = 0;	/* wLength */
	i = usb_control_transaction(dev, setup, 8, NULL, 0);
	if(i == 0)
		dev->adr = adr;
	free_dma_mem(mem_handle);
	return i;
}
/*****************************************************************************
*****************************************************************************/
static int usb_display_string(usb_dev_t *dev, unsigned string_num)
{
	unsigned char FAR *setup, FAR *data;
	int mem_handle, i;
	unsigned len, j;

	setup = (unsigned char FAR *)alloc_dma_mem(&mem_handle, 8 + 256, 1);
	if(setup == NULL)
		return -1;
	data = &setup[8];
// xxx - first byte returned (string length) on first call is 0xE6
// on the second call, it's 0x32, which is the correct value
	len = 1;
	setup[0] = 0x80;		/* bmRequestType */
	setup[1] = USB_REQ_GET_DESCRIPTOR;/* bRequest, =6 */
	setup[2] = string_num; 		/* wValue LSB: descriptor index */
	  setup[3] = USB_DTYPE_STRING;	/* wValue MSB: descriptor type, =1 */
	setup[4] = 0;			/* wIndex: zero or language ID */
	  setup[5] = 0;
	setup[6] = len;			/* wLength: descriptor length */
	  setup[7] = 0;
	i = usb_control_transaction(dev, setup, 8, data, len);
	if(i != 0)
ERR:	{
		free_dma_mem(mem_handle);
		return i;
	}
	len = data[0];
	setup[6] = len;
	i = usb_control_transaction(dev, setup, 8, data, len);
	if(i != 0)
		goto ERR;
	len = data[0];
/* this assumes Latin-1 character set */
	for(j = 2; j < len; j += 2)
		putchar(data[j]);
	free_dma_mem(mem_handle);
	return 0;
}
/*****************************************************************************
Device descriptor
	Field		Field
Offset	name		size	Description
------	---------------	-----	-------------
0	bLength		1	Length of this device descriptor
1	bDescriptorType	1	USB_DTYPE_DEVICE=1
2-3	bcdUSB		2	USB version in BCD format, minor first
4	bDeviceClass	1
5	bDeviceSubClass	1
6	bDeviceProtocol	1
7	bMaxPacketSize0	1	Max. packet size for endpoint #0 (8,16,32,64)
8-9	idVendor	2
10-11	idProduct	2
12-13	bcdDevice	2
14	iManufacturer	1	String index
15	iProduct	1	String index
16	iSerialNumber	1	String index
17	bNumConfig.s	1
*****************************************************************************/
static int usb_dump_device(usb_dev_t *dev)
{
	int i;

	printf("\nDEVICE INFO for address %u:\n", dev->adr);
	printf("USB ver %X.%X", dev->usb_ver_major, dev->usb_ver_minor);
	printf(", class:sub:proto=%u:%u:%u", dev->_class,
		dev->subclass, dev->proto);
	printf(", vendorID=0x%04X, deviceID=0x%04X\n",
		dev->vendor_id, dev->product_id);
	if(dev->mfgr_string != 0)
	{
		printf("Manufacturer: ");
		i = usb_display_string(dev, dev->mfgr_string);
		if(i != 0)
			return i;
		putchar('\n');
	}
	if(dev->prod_string != 0)
	{
		printf("Product: ");
		i = usb_display_string(dev, dev->prod_string);
		if(i != 0)
			return i;
		putchar('\n');
	}
	if(dev->sernum_string != 0)
	{
		printf("Serial number: ");
		i = usb_display_string(dev, dev->sernum_string);
		if(i != 0)
			return i;
		putchar('\n');
	}
	printf("Device has %u configuration(s)\n", dev->num_configs);
	return 0;
}
/*****************************************************************************
Configuration descriptor
	Field		Field
Offset	name		size	Description
------	---------------	-----	-------------
0	bLength		1	Length of this configuration descriptor
1	bDescriptorType	1	USB_DTYPE_CONFIG=2
2-3	wTotalLength	2	Combined length of this descriptor and all
				subordinate descriptors (interface & endpoint)
4	bNumInterfaces	1
5	bConfig.Value	1	1-based
6	iConfiguration	1	String index
7	bmAttributes	1	b7=1, b6=self-powered,b5=remote wakeup
8	bMaxPower	1	MaxCurrent, actually, in units of 2 mA
*****************************************************************************/
static int usb_dump_config(usb_dev_t *dev, unsigned config_num)
{
	usb_config_t *c;
	int i;

	if(config_num >= dev->num_configs)
	{
		printf("Error: config_num (%u) >= num_configs (%u)\n",
			config_num, dev->num_configs);
		return -1;
	}
	c = &dev->configs[config_num];
	printf("  CONFIG INFO for address %u, config %u:\n",
		dev->adr, c->config_num);
	printf("  Config has %u interface(s)", c->num_ifs);
	printf(", attributes=0x%02X", c->attrib);
	printf(", %umA max current\n", c->max_current);
	if(c->config_string != 0)
	{
		printf("  Config name: ");
		i = usb_display_string(dev, c->config_string);
		if(i != 0)
			return i;
		putchar('\n');
	}
	return 0;
}
/*****************************************************************************
Interface descriptor
	Field		Field
Offset	name		size	Description
------	---------------	-----	-------------
0	bLength		1	Length of this interface descriptor
1	bDescriptorType	1	USB_DTYPE_INTERFACE=2
2	bInterfaceNumber 1	0-based
3	bAlternateSetting 1
4	bNumEndpoints	1
5	bInterfaceClass	1
6	bI.faceSubClass	1
7	bI.faceProtocol	1
8	iInterface	1	String index
*****************************************************************************/
static int usb_dump_iface(usb_dev_t *dev, unsigned config_num,
		unsigned iface_num)
{
	usb_config_t *c;
	usb_iface_t *i;
	int err;

	if(config_num >= dev->num_configs)
	{
		printf("Error: config_num (%u) >= num_configs (%u)\n",
			config_num, dev->num_configs);
		return -1;
	}
	c = &dev->configs[config_num];
	if(iface_num >= c->num_ifs)
	{
		printf("Error: interface_num (%u) >= num_interfaces (%u)\n",
			iface_num, c->num_ifs);
		return -1;
	}
	i = &c->iface[iface_num];
	printf("    INTERFACE INFO for address %u, config %u, "
		"interface %u:\n", dev->adr, c->config_num, i->iface_num);
	printf("    Alternate setting=%u", i->alt);
	printf(", %u endpoint(s)", i->num_endp);
	printf(", class:sub:proto=%u:%u:%u\n",
		i->_class, i->subclass, i->proto);
	if(i->iface_string != 0)
	{
		printf("    Interface name: ");
		err = usb_display_string(dev, i->iface_string);
		if(err != 0)
			return err;
		putchar('\n');
	}
	return 0;
}
/*****************************************************************************
Endpoint descriptor
	Field		Field
Offset	name		size	Description
------	---------------	-----	-------------
0	bLength		1	Length of this endpoint descriptor
1	bDescriptorType	1	USB_DTYPE_ENDPOINT=2
2	bEndpointAddress 1	b7=IN/!OUT, b3-b0=endpoint number
3	bmAttributes	1	b5-b4=usage (?), b3-b2=synchronization (?),
				b1-b0=transfer type (3=interrupt, 2=bulk,
				1=isochronous, 0=control)
4-5	wMaxPacketSize	2
6	bInterval	1	Polling interval in 1 ms frames (for low/full
				speed) or 125 us microframes (for high speed)
*****************************************************************************/
static int usb_dump_endp(usb_dev_t *dev, unsigned config_num,
		unsigned iface_num, unsigned endp_num)
{
	usb_config_t *c;
	usb_iface_t *i;
	usb_endp_t *e;

	if(config_num >= dev->num_configs)
	{
		printf("Error: config_num (%u) >= num_configs (%u)\n",
			config_num, dev->num_configs);
		return -1;
	}
	c = &dev->configs[config_num];
	if(iface_num >= c->num_ifs)
	{
		printf("Error: interface_num (%u) >= num_interfaces (%u)\n",
			iface_num, c->num_ifs);
		return -1;
	}
	i = &c->iface[iface_num];
	if(endp_num >= i->num_endp)
	{
		printf("Error: endpoint_num (%u) >= num_endpoints (%u)\n",
			endp_num, i->num_endp);
		return -1;
	}
	e = &i->endp[endp_num];
	printf("      ENDPOINT INFO for address %u, config %u, interface "
		"%u, endpoint %u:\n", dev->adr, c->config_num, i->iface_num,
		e->adr & 0x0F);
	printf("      %s, attrib=0x%02X (",
		(e->adr & 0x80) ? "IN" : "OUT", e->attrib);
	switch(e->attrib & 0x03)
	{
	case 0:
		printf("control");
		break;
	case 1:
		printf("isochronous");
		break;
	case 2:
		printf("bulk");
		break;
	case 3:
		printf("interrupt");
		break;
	}
	printf("), max_packet_size=%u\n      polling interval=%u usec\n",
		e->max_packet_size, e->polling_interval);
	return 0;
}
/*****************************************************************************
*****************************************************************************/
static unsigned read_le16(void FAR *buf_ptr)
{
	unsigned char FAR *buf = (unsigned char FAR *)buf_ptr;

	return buf[0] + 0x100 * (unsigned)buf[1];
}
/*****************************************************************************
*****************************************************************************/
int usb_enumerate(void)
{
	unsigned ddesc_len, cdesc_len, i, j, c_num, i_num, e_num = 0;
	unsigned char FAR *data1, FAR *data2;
	int mem_handle1, mem_handle2;
	usb_iface_t *iface = NULL;
	usb_config_t *c = NULL;
	usb_endp_t *e;
	usb_dev_t dev;

memset(&dev, 0, sizeof(dev));
/* temporary values */
	dev.adr = 0;
	dev.endpoint0_max_packet_size = 8;
/* get first 8 bytes of the device descriptor */
	data1 = (unsigned char FAR *)alloc_dma_mem(&mem_handle1, 8 + 256, 0);
	if(data1 == NULL)
		return -1;
	if(usb_get_descriptor(&dev, USB_DTYPE_DEVICE, 0, 8, data1))
	{
		printf("Error reading device descriptor (1)\n");
		free_dma_mem(mem_handle1);
		return -1;
	}
	DEBUG(
		if(g_debug)
		{
			printf("Linear address of data buffer=0x%lX\n",
				PTR2LINEAR(&data1[0]));
			printf("    Hex dump of received data:\n");
			dump(data1, 8);
		}
	)
/* get what data we can from the first 8 bytes */
	ddesc_len = MIN(18,	data1[0]); /* device descriptor length */
	dev.usb_ver_minor =	data1[2];
	dev.usb_ver_major =	data1[3];
	dev._class =		data1[4];
	dev.subclass =		data1[5];
	dev.proto =		data1[6];
	dev.endpoint0_max_packet_size = data1[7]; /* 8, 16, 32, or 64 */
/* set device address */
	i = 0x5A;
	if(usb_set_address(&dev, i))
	{
		printf("Error setting device address to %u\n", i);
		free_dma_mem(mem_handle1);
		return -1;
	}
/* got endpoint0_max_packet_size; can now
get the rest of the device descriptor (up to 18 bytes) */
	if(usb_get_descriptor(&dev, USB_DTYPE_DEVICE, 0, ddesc_len, data1))
	{
		printf("Error reading device descriptor (2)\n");
		free_dma_mem(mem_handle1);
		return -1;
	}
	DEBUG(
		if(g_debug)
		{
			printf("    Hex dump of received data:\n");
			dump(data1, ddesc_len);
		}
	)
	dev.vendor_id = read_le16(&data1[8]);
	dev.product_id = read_le16(&data1[10]);
	dev.mfgr_string =	data1[14];
	dev.prod_string =	data1[15];
	dev.sernum_string =	data1[16];
	dev.num_configs =	data1[17];
/* allocate memory for configs */
	dev.configs = malloc(dev.num_configs * sizeof(usb_config_t));
	if(dev.configs == NULL)
MEM:	{
		printf("Error: out of memory\n");
		free_dma_mem(mem_handle1);
		return -1;
	}
/* load configs */
	for(c_num = 0; c_num < dev.num_configs; c_num++)
	{
		if(usb_get_descriptor(&dev, USB_DTYPE_CONFIG,
			c_num, 9, data1))
		{
			printf("Error reading configuration descriptor (1)\n");
			free_dma_mem(mem_handle1);
			return -1;
		}
		DEBUG(
			if(g_debug)
			{
				printf("    Hex dump of received data:\n");
				dump(data1, 9);
			}
		)
		c = &dev.configs[c_num];
		c->num_ifs =		data1[4];
		c->config_num =		data1[5];
		c->config_string =	data1[6];
		c->attrib =		data1[7];
		c->max_current =	data1[8] * 2;
/* data[2-3] contains combined length of this descriptor and all subordinate
descriptors (e.g. interface descriptors) for this configuration.
Allocate memory and load it all. */
		cdesc_len = read_le16(&data1[2]);
		data2 = (unsigned char FAR *)alloc_dma_mem(
			&mem_handle2, cdesc_len, 1);
		if(data2 == NULL)
			goto MEM;
/* allocate memory for interfaces */
		c->iface = malloc(c->num_ifs * sizeof(usb_iface_t));
		if(c->iface == NULL)
		{
			free_dma_mem(mem_handle2);
			goto MEM;
		}
/* load config descriptor and associated interface, and endpoint descriptors */
		if(usb_get_descriptor(&dev, USB_DTYPE_CONFIG,
			c_num, cdesc_len, data2))
		{
			free_dma_mem(mem_handle2);
			usb_destroy_dev(&dev);
			printf("Error reading configuration descriptor (2)\n");
			free_dma_mem(mem_handle1);
			return -1;
		}
/* find interface and endpoint descriptors and read them */
		i_num = 0;
		for(j = 0; j < cdesc_len; )
		{
			if(data2[j + 1] == USB_DTYPE_INTERFACE)
			{
				if(i_num >= c->num_ifs)
					break;
				iface = &c->iface[i_num];
				iface->iface_num =	data2[j + 2];
				iface->alt =		data2[j + 3];
				iface->num_endp =	data2[j + 4];
				iface->_class =		data2[j + 5];
				iface->subclass =	data2[j + 6];
				iface->proto =		data2[j + 7];
				iface->iface_string =	data2[j + 8];
				i_num++;
/* allocate memory for endpoints */
				iface->endp = malloc(iface->num_endp *
					sizeof(usb_endp_t));
				if(c->iface == NULL)
				{
					free_dma_mem(mem_handle2);
					goto MEM;
				}
				e_num = 0;
			}
			else if(data2[j + 1] == USB_DTYPE_ENDPOINT)
			{
				if(e_num >= iface->num_endp)
					break;
				e = &iface->endp[e_num];
				e->adr =		data2[j + 2];
				e->attrib =		data2[j + 3];
				e->max_packet_size =
					read_le16(&data2[j + 4]);
// xxx - x125 for high-speed USB
				e->polling_interval =
						1000 *	data2[j + 6];
				e_num++;
			}
			j += data2[j + 0];
		}
		free_dma_mem(mem_handle2);
	}
/* dump info */
	usb_dump_device(&dev);
	for(c_num = 0; c_num < dev.num_configs; c_num++)
	{
		usb_dump_config(&dev, c_num);
		for(i_num = 0; i_num < c->num_ifs; i_num++)
		{
			usb_dump_iface(&dev, c_num, i_num);
			for(e_num = 0; e_num < iface->num_endp; e_num++)
				usb_dump_endp(&dev, c_num, i_num, e_num);
		}
	}
/* done with this device */
	usb_destroy_dev(&dev);
	free_dma_mem(mem_handle1);
	return 0;
}
