#include <stdio.h> /* printf() */
#if defined(__DJGPP__)
#include <sys/nearptr.h> /* __djgpp_nearptr_enable() */
#include <crt0.h> /* _CRT0_FLAG_..., _crt0_startup_flags */
#endif

/* IMPORTS:
from UHCI.C */
int uhci_detect(void);
int uhci_init(void);
void uhci_display_port_status(void);

/* from USB.C */
int usb_enumerate(void);
/*****************************************************************************
*****************************************************************************/
int main(void)
{

#if defined(__DJGPP__)
/* turn off data segment limit, for nearptr access */
	if(!(_crt0_startup_flags & _CRT0_FLAG_NEARPTR))
	{
		if(!__djgpp_nearptr_enable())
		{
			printf("Error: can't enable near pointer "
				"access (WinNT/2k/XP?)\n");
			return 1;
		}
printf("nearptr enabled\n");
	}
#endif
/* detect and set up UHCI controller */
	if(uhci_detect())
		return 1;
	if(uhci_init())
		return 1;
	uhci_display_port_status();
/* enumerate USB devices */
	(void)usb_enumerate();
	return 0;
}
